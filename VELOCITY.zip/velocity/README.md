# VELOCITY (early build, v0.1.0)

Advisory input-pattern predictor for Geometry Dash (Geode). It watches the player's own
press/release rhythm per game mode, forecasts the next event, and scores itself against what
the player actually does. It does NOT inject or alter inputs.

## Status
| Piece | State |
|---|---|
| `src/core` (analyzer, timing, prediction, profiles, analytics, mode detection) | Written; 9 unit-test groups pass (`tests/core_test.cpp`) |
| `src/Velocity.cpp` (Geode hooks, settings, text overlay) | Written, **never compiled against the SDK** |
| Android32 / Android64 / Windows builds | **Untested** - CI workflow provided, not yet run |
| Dashboard, analytics page, profile editor, floating button, import/export | Not started |

## Core tests (no SDK needed)
    g++ -std=c++17 -O2 -Wall -Wextra -Isrc src/core/*.cpp tests/core_test.cpp -o core_test && ./core_test

## Build (needs Geode CLI + SDK; confirm flags against docs.geode-sdk.org)
    geode sdk install            # or set GEODE_SDK
    geode build                  # host platform (Windows)
For Android32/Android64 push to GitHub and run the "Build VELOCITY" workflow, or build locally
with the Android NDK per the Geode docs. Set `"developer"` in `mod.json` first, and set `"geode"`
to the exact Geode version you build against.
