// Geode glue. NOT compiled or run against the SDK yet: hook signatures and PlayLayer/PlayerObject
// field names below are from memory of the Geode bindings and must be checked by the first CI build.
#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <chrono>

#include "core/AnalyticsManager.hpp"
#include "core/InputAnalyzer.hpp"
#include "core/ModeDetector.hpp"
#include "core/PredictionEngine.hpp"
#include "core/ProfileManager.hpp"
#include "core/TimingEngine.hpp"

using namespace geode::prelude;

namespace {
struct Runtime {
    vel::InputAnalyzer analyzer;
    vel::TimingEngine timing;
    vel::PredictionEngine engine;
    vel::ProfileManager profiles;
    vel::AnalyticsManager analytics;
    vel::GameMode mode = vel::GameMode::Cube;
    bool enabled = true;

    static Runtime& get() { static Runtime r; return r; }

    // Settings are read on level (re)start, never per frame.
    void loadSettings() {
        auto* mod = Mod::get();
        enabled = mod->getSettingValue<bool>("enabled");
        for (size_t i = 0; i < vel::kModeCount; ++i) {
            auto m = static_cast<vel::GameMode>(i);
            std::string key = std::string("mode-") + vel::modeKey(m);
            profiles.setModeEnabled(m, mod->getSettingValue<bool>(key + "-enabled"));
            profiles.setModeProfile(m, vel::parseProfile(mod->getSettingValue<std::string>(key + "-profile")));
        }
        vel::ProfileParams c;
        c.confidenceThreshold = static_cast<float>(mod->getSettingValue<double>("custom-confidence"));
        c.minSamples = static_cast<int>(mod->getSettingValue<int64_t>("custom-min-samples"));
        c.maxJitter = static_cast<float>(mod->getSettingValue<double>("custom-max-jitter"));
        c.toleranceFrac = static_cast<float>(mod->getSettingValue<double>("custom-tolerance"));
        c.adaptive = mod->getSettingValue<bool>("custom-adaptive");
        if (!profiles.setCustom(c)) log::warn("VELOCITY: invalid custom profile ignored");
    }

    // Wipes every piece of per-run state so nothing stale leaks into a new attempt/level.
    void resetState() { analyzer.reset(); engine.reset(); timing.reset(); }

    void onButton(double levelTime, bool down, const vel::ModeFlags& flags) {
        using clock = std::chrono::steady_clock;
        const auto t0 = clock::now();
        const auto m = vel::detectMode(flags);
        if (m != mode) { mode = m; analyzer.reset(); engine.reset(); } // patterns don't carry across modes
        if (!profiles.modeEnabled(mode)) return;
        const auto kind = down ? vel::InputKind::Press : vel::InputKind::Release;
        if (!analyzer.record(levelTime, kind)) return; // duplicate/impossible event
        analytics.recordInput(mode);
        engine.configure(profiles.resolve(mode), true);
        const auto step = engine.onInput(levelTime, kind, analyzer.estimate());
        analytics.recordOutcome(mode, step.resolved);
        const auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(clock::now() - t0).count();
        analytics.recordDecision(mode, step.next, static_cast<uint64_t>(ns));
    }
};
} // namespace

class $modify(VelBaseLayer, GJBaseGameLayer) {
    void handleButton(bool down, int button, bool isPlayer1) {
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
        auto& rt = Runtime::get();
        if (!rt.enabled || button != 1 || !isPlayer1 || !m_player1) return;
        if (!typeinfo_cast<PlayLayer*>(this)) return; // ignore the editor
        vel::ModeFlags f;
        f.ship = m_player1->m_isShip;   f.ufo = m_player1->m_isBird;  f.ball = m_player1->m_isBall;
        f.wave = m_player1->m_isDart;   f.robot = m_player1->m_isRobot;
        f.spider = m_player1->m_isSpider; f.swing = m_player1->m_isSwing;
        rt.onButton(m_gameState.m_levelTime, down, f);
    }
};

class $modify(VelPlayLayer, PlayLayer) {
    struct Fields { CCLabelBMFont* label = nullptr; };

    void resetLevel() {
        PlayLayer::resetLevel();
        auto& rt = Runtime::get();
        rt.loadSettings();
        rt.resetState();
        if (!m_fields->label) {
            auto* l = CCLabelBMFont::create("", "bigFont.fnt");
            l->setScale(0.3f); l->setAnchorPoint({0.f, 1.f});
            auto ws = CCDirector::get()->getWinSize();
            l->setPosition({8.f, ws.height - 8.f});
            this->addChild(l, 1000);
            m_fields->label = l;
        }
    }

    void onQuit() {
        Runtime::get().resetState();
        PlayLayer::onQuit();
    }

    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);
        auto& rt = Runtime::get();
        auto* label = m_fields->label;
        if (!rt.enabled) { if (label) label->setVisible(false); return; }
        rt.timing.onFrame(dt);
        rt.analytics.recordOutcome(rt.mode, rt.engine.tick(m_gameState.m_levelTime));
        if (!label) return;

        static uint32_t frame = 0;
        const bool show = Mod::get()->getSettingValue<bool>("overlay");
        label->setVisible(show);
        if (!show || (++frame % 15) != 0) return; // refresh ~4x/s at 60 fps
        const auto s = rt.analytics.session(rt.mode);
        const auto& p = rt.engine.pending();
        label->setOpacity(static_cast<GLubyte>(255.0 * Mod::get()->getSettingValue<double>("overlay-opacity")));
        label->setString(fmt::format(
            "VEL {} | {}\nconf {:.0f}%  hit {}  acc {}/{}\nfps {:.0f}  steady {:.0f}%",
            vel::modeName(rt.mode),
            p.valid ? (p.kind == vel::InputKind::Press ? "next: press" : "next: release") : "no prediction",
            p.valid ? p.confidence * 100.f : 0.f,
            (s.hits + s.misses) ? fmt::format("{:.0f}%", s.hitRate() * 100.0) : std::string("n/a"),
            s.accepted, s.attempts,
            rt.timing.fps(), rt.timing.consistency() * 100.0).c_str());
    }
};
