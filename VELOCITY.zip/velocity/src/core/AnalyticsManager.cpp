#include "AnalyticsManager.hpp"
#include <algorithm>
namespace vel {

Stats& Stats::operator+=(const Stats& o) {
    inputs += o.inputs; attempts += o.attempts; accepted += o.accepted; rejected += o.rejected;
    hits += o.hits; misses += o.misses; procNs += o.procNs; procCount += o.procCount;
    for (size_t i = 0; i < confHist.size(); ++i) confHist[i] += o.confHist[i];
    return *this;
}

void AnalyticsManager::recordInput(GameMode m) {
    ++m_session[idx(m)].inputs; ++m_life[idx(m)].inputs;
}

void AnalyticsManager::recordDecision(GameMode m, const Prediction& p, uint64_t procNs) {
    for (Stats* s : {&m_session[idx(m)], &m_life[idx(m)]}) {
        ++s->attempts;
        (p.valid ? s->accepted : s->rejected)++;
        s->procNs += procNs; ++s->procCount;
        // Histogram only covers decisions where a confidence was actually computed.
        if (p.valid || p.reason == Reject::LowConfidence) {
            size_t b = std::min<size_t>(9, static_cast<size_t>(p.confidence * 10.0f));
            ++s->confHist[b];
        }
    }
}

void AnalyticsManager::recordOutcome(GameMode m, Outcome o) {
    if (o == Outcome::None) return;
    for (Stats* s : {&m_session[idx(m)], &m_life[idx(m)]}) (o == Outcome::Hit ? s->hits : s->misses)++;
}

Stats AnalyticsManager::sessionTotal() const { Stats t; for (auto& s : m_session) t += s; return t; }
Stats AnalyticsManager::lifetimeTotal() const { Stats t; for (auto& s : m_life) t += s; return t; }
}
