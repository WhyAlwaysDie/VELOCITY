#pragma once
#include "PredictionEngine.hpp"
#include "Types.hpp"
#include <array>
namespace vel {

struct Stats {
    uint64_t inputs = 0, attempts = 0, accepted = 0, rejected = 0, hits = 0, misses = 0;
    std::array<uint64_t, 10> confHist{}; // bucket i = confidence in [i/10, (i+1)/10)
    uint64_t procNs = 0, procCount = 0;
    double avgProcessingUs() const { return procCount ? (procNs / 1000.0) / procCount : 0.0; }
    double hitRate() const { uint64_t n = hits + misses; return n ? double(hits) / n : 0.0; }
    Stats& operator+=(const Stats& o);
};

// Counters only: every number comes from a real event. Lifetime stats are loaded by the
// host (Geode glue) and updated in lockstep with session stats.
class AnalyticsManager {
public:
    void recordInput(GameMode m);
    void recordDecision(GameMode m, const Prediction& p, uint64_t procNs);
    void recordOutcome(GameMode m, Outcome o);
    void resetSession() { m_session = {}; }
    void loadLifetime(GameMode m, const Stats& s) { m_life[idx(m)] = s; }
    const Stats& session(GameMode m) const { return m_session[idx(m)]; }
    const Stats& lifetime(GameMode m) const { return m_life[idx(m)]; }
    Stats sessionTotal() const;
    Stats lifetimeTotal() const;
private:
    static size_t idx(GameMode m) { return static_cast<size_t>(m) % kModeCount; }
    std::array<Stats, kModeCount> m_session{}, m_life{};
};
}
