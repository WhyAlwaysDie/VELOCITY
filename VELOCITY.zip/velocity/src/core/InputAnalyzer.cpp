#include "InputAnalyzer.hpp"
#include <algorithm>
#include <cmath>
namespace vel {
namespace {
double median(double* a, size_t n) { // n <= 8, sort in place (no allocation)
    std::sort(a, a + n);
    return (n % 2) ? a[n / 2] : 0.5 * (a[n / 2 - 1] + a[n / 2]);
}
}
void InputAnalyzer::reset() { m_head = 0; m_count = 0; m_down = false; m_lastT = -1e300; m_total = 0; }

bool InputAnalyzer::record(double t, InputKind k) {
    if (!std::isfinite(t) || t < m_lastT) return false;
    if (k == InputKind::Press && m_down) return false;     // duplicate press
    if (k == InputKind::Release && !m_down) return false;  // release without press
    m_ev[m_head] = {t, k};
    m_head = (m_head + 1) % kCap;
    if (m_count < kCap) ++m_count;
    m_down = (k == InputKind::Press);
    m_lastT = t;
    ++m_total;
    return true;
}

PatternEstimate InputAnalyzer::estimate() const {
    PatternEstimate e; e.isDown = m_down;
    double presses[kCap], holds[kCap];
    size_t np = 0, nh = 0; double lastPress = 0; bool havePress = false;
    const size_t start = (m_head + kCap - m_count) % kCap;
    for (size_t i = 0; i < m_count; ++i) {
        const InputEvent& ev = m_ev[(start + i) % kCap];
        if (ev.kind == InputKind::Press) { presses[np++] = ev.t; lastPress = ev.t; havePress = true; }
        else if (havePress) { holds[nh++] = ev.t - lastPress; havePress = false; }
    }
    if (np == 0) return e;
    e.lastPress = presses[np - 1];
    if (np < 3) return e; // need >= 2 intervals for a pattern

    // Use only the most recent kMaxIntervals intervals so old behaviour ages out.
    const size_t first = np > kMaxIntervals + 1 ? np - (kMaxIntervals + 1) : 0;
    double iv[kMaxIntervals]; size_t ni = 0;
    for (size_t i = first + 1; i < np; ++i) iv[ni++] = presses[i] - presses[i - 1];
    double mean = 0; for (size_t i = 0; i < ni; ++i) mean += iv[i];
    mean /= static_cast<double>(ni);
    if (mean <= 0) return e;
    double var = 0; for (size_t i = 0; i < ni; ++i) { double d = iv[i] - mean; var += d * d; }
    e.cv = std::sqrt(var / static_cast<double>(ni)) / mean;
    e.samples = static_cast<int>(ni);
    e.period = median(iv, ni);

    if (nh > 0) {
        const size_t hs = nh > kMaxIntervals ? nh - kMaxIntervals : 0;
        double h[kMaxIntervals]; size_t n = 0;
        for (size_t i = hs; i < nh; ++i) h[n++] = holds[i];
        e.hold = median(h, n);
    }
    e.valid = e.period > 0;
    return e;
}
}
