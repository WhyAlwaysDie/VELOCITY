#pragma once
#include "Types.hpp"
#include <array>
namespace vel {

struct PatternEstimate {
    bool valid = false;
    int samples = 0;       // number of press-to-press intervals used
    double period = 0;     // median press-to-press interval (s)
    double hold = 0;       // median hold duration (s), 0 if unknown
    double cv = 1.0;       // coefficient of variation of intervals (lower = steadier)
    double lastPress = 0;
    bool isDown = false;
};

// Fixed-size ring buffer of input events. Rejects duplicate/out-of-order events so the
// rest of the engine never sees an impossible press/release sequence.
class InputAnalyzer {
public:
    static constexpr size_t kCap = 32;
    static constexpr size_t kMaxIntervals = 8;
    bool record(double t, InputKind k);   // false = rejected
    void reset();
    PatternEstimate estimate() const;
    uint64_t totalEvents() const { return m_total; }
    bool isDown() const { return m_down; }
private:
    std::array<InputEvent, kCap> m_ev{};
    size_t m_head = 0, m_count = 0;
    bool m_down = false;
    double m_lastT = -1e300;
    uint64_t m_total = 0;
};
}
