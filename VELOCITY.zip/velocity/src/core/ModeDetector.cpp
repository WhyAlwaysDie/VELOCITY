#include "ModeDetector.hpp"
namespace vel {
GameMode detectMode(const ModeFlags& f) {
    // GD modes are mutually exclusive; the order only matters for corrupt input.
    if (f.ship)   return GameMode::Ship;
    if (f.ufo)    return GameMode::UFO;
    if (f.ball)   return GameMode::Ball;
    if (f.wave)   return GameMode::Wave;
    if (f.robot)  return GameMode::Robot;
    if (f.spider) return GameMode::Spider;
    if (f.swing)  return GameMode::Swing;
    return GameMode::Cube;
}
static const char* kNames[] = {"Cube","Ship","Ball","UFO","Wave","Robot","Spider","Swing"};
static const char* kKeys[]  = {"cube","ship","ball","ufo","wave","robot","spider","swing"};
const char* modeName(GameMode m) { return kNames[static_cast<size_t>(m) % kModeCount]; }
const char* modeKey(GameMode m)  { return kKeys[static_cast<size_t>(m) % kModeCount]; }
}
