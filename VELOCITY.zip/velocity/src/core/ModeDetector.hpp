#pragma once
#include "Types.hpp"
namespace vel {
GameMode detectMode(const ModeFlags& f);
const char* modeName(GameMode m); // "Cube"
const char* modeKey(GameMode m);  // "cube" (used in settings keys)
}
