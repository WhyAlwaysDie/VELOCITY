#include "PredictionEngine.hpp"
#include <algorithm>
#include <cmath>
namespace vel {

void PredictionEngine::reset() { m_pending = Prediction{}; m_hitRate = 1.0f; }

void PredictionEngine::updateHitRate(Outcome o) {
    if (o == Outcome::None) return;
    m_hitRate += 0.2f * ((o == Outcome::Hit ? 1.0f : 0.0f) - m_hitRate);
}

Outcome PredictionEngine::resolve(double t, InputKind k) {
    if (!m_pending.valid) return Outcome::None;
    const bool hit = (k == m_pending.kind) && std::fabs(t - m_pending.dueAt) <= m_pending.tolerance;
    m_pending = Prediction{};
    const Outcome o = hit ? Outcome::Hit : Outcome::Miss;
    updateHitRate(o);
    return o;
}

Outcome PredictionEngine::tick(double now) {
    if (m_pending.valid && now > m_pending.dueAt + m_pending.tolerance) {
        m_pending = Prediction{};
        updateHitRate(Outcome::Miss);
        return Outcome::Miss;
    }
    return Outcome::None;
}

Prediction PredictionEngine::evaluate(double t, InputKind k, const PatternEstimate& e) const {
    Prediction p;
    auto reject = [&](Reject r, float conf = 0) { p.valid = false; p.reason = r; p.confidence = conf; return p; };
    if (!m_enabled) return reject(Reject::Disabled);
    if (!e.valid) return reject(Reject::NoPattern);
    if (e.samples < m_p.minSamples) return reject(Reject::Insufficient);
    if (e.cv > m_p.maxJitter) return reject(Reject::Jittery);

    // Confidence = 70% steadiness (how far cv is below the allowed jitter) + 30% sample depth.
    const float stability = std::clamp(1.0f - static_cast<float>(e.cv) / m_p.maxJitter, 0.0f, 1.0f);
    const float depth = std::min(1.0f, static_cast<float>(e.samples) / (2.0f * static_cast<float>(m_p.minSamples)));
    const float conf = 0.7f * stability + 0.3f * depth;

    // Adaptive: demand more confidence while recent predictions have been missing.
    const float thr = m_p.confidenceThreshold + (m_p.adaptive ? 0.25f * (1.0f - m_hitRate) : 0.0f);
    if (conf < thr) return reject(Reject::LowConfidence, conf);

    // After a press the next event is a release; after a release, the next press.
    double due;
    if (k == InputKind::Press) {
        if (e.hold <= 0) return reject(Reject::NoHold, conf);
        due = e.lastPress + e.hold;
        p.kind = InputKind::Release;
    } else {
        due = e.lastPress + e.period;
        p.kind = InputKind::Press;
    }
    if (due < t) return reject(Reject::Stale, conf); // predicted moment already passed

    p.valid = true; p.dueAt = due; p.confidence = conf; p.reason = Reject::None;
    p.tolerance = std::max(0.010, static_cast<double>(m_p.toleranceFrac) * e.period);
    return p;
}

StepResult PredictionEngine::onInput(double t, InputKind k, const PatternEstimate& est) {
    StepResult r;
    r.resolved = resolve(t, k);   // score the previous prediction first
    r.next = evaluate(t, k, est);
    if (r.next.valid) m_pending = r.next;
    return r;
}
}
