#pragma once
#include "InputAnalyzer.hpp"
#include "Types.hpp"
namespace vel {

enum class Reject : uint8_t { None, Disabled, NoPattern, Insufficient, Jittery, LowConfidence, NoHold, Stale };

struct Prediction {
    bool valid = false;
    InputKind kind = InputKind::Press; // the NEXT expected player event
    double dueAt = 0;                  // level time (s)
    double tolerance = 0;              // hit window half-width (s)
    float confidence = 0;              // 0 if rejected before confidence was computed
    Reject reason = Reject::None;
};

struct StepResult { Outcome resolved = Outcome::None; Prediction next; };

// Advisory predictor: forecasts the player's next press/release from their own rhythm and
// scores itself against what the player actually does. It never injects input.
class PredictionEngine {
public:
    void configure(const ProfileParams& p, bool enabled) { m_p = p; m_enabled = enabled; }
    void reset();
    // Call once per accepted real input event (after InputAnalyzer::record).
    StepResult onInput(double t, InputKind k, const PatternEstimate& est);
    // Call each frame with level time; expires an unanswered prediction as a miss.
    Outcome tick(double now);
    const Prediction& pending() const { return m_pending; }
    float hitRate() const { return m_hitRate; }
private:
    Prediction evaluate(double t, InputKind k, const PatternEstimate& e) const;
    Outcome resolve(double t, InputKind k);
    void updateHitRate(Outcome o);
    ProfileParams m_p{};
    bool m_enabled = true;
    Prediction m_pending{};
    float m_hitRate = 1.0f; // EMA of recent outcomes; only used by Adaptive profiles
};
}
