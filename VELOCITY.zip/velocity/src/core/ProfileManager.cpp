#include "ProfileManager.hpp"
#include <algorithm>
#include <cmath>
namespace vel {

static const char* kProfileKeys[] = {"standard","precision","adaptive","experimental","custom"};
const char* profileKey(ProfileId id) { return kProfileKeys[static_cast<size_t>(id) % 5]; }
ProfileId parseProfile(const std::string& s) {
    for (size_t i = 0; i < 5; ++i) if (s == kProfileKeys[i]) return static_cast<ProfileId>(i);
    return ProfileId::Standard;
}

ProfileParams builtinProfile(ProfileId id) {
    switch (id) {
        case ProfileId::Precision:    return {0.80f, 6, 0.08f, 0.10f, false};
        case ProfileId::Adaptive:     return {0.55f, 4, 0.18f, 0.20f, true};
        // Experimental is currently just looser thresholds; no separate algorithm yet.
        case ProfileId::Experimental: return {0.45f, 3, 0.25f, 0.30f, false};
        default:                      return ProfileParams{}; // Standard
    }
}

bool ProfileManager::validate(ProfileParams& p) {
    if (!std::isfinite(p.confidenceThreshold) || !std::isfinite(p.maxJitter) || !std::isfinite(p.toleranceFrac)) return false;
    p.confidenceThreshold = std::clamp(p.confidenceThreshold, 0.0f, 1.0f);
    p.minSamples = std::clamp(p.minSamples, 2, 12);
    p.maxJitter = std::clamp(p.maxJitter, 0.02f, 0.5f);
    p.toleranceFrac = std::clamp(p.toleranceFrac, 0.05f, 0.5f);
    return true;
}
bool ProfileManager::setCustom(ProfileParams p) { if (!validate(p)) return false; m_custom = p; return true; }
ProfileParams ProfileManager::resolve(GameMode m) const {
    const ProfileId id = m_modes[idx(m)].profile;
    return id == ProfileId::Custom ? m_custom : builtinProfile(id);
}
void ProfileManager::resetAll() { for (auto& c : m_modes) c = ModeConfig{}; m_custom = ProfileParams{}; }
}
