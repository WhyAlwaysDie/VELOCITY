#pragma once
#include "Types.hpp"
#include <array>
#include <string>
namespace vel {

const char* profileKey(ProfileId id);               // "standard"
ProfileId parseProfile(const std::string& s);       // unknown -> Standard
ProfileParams builtinProfile(ProfileId id);         // Custom returns Standard defaults

class ProfileManager {
public:
    ProfileManager() { resetAll(); }
    // Per-mode state is fully independent: changing Ship never touches Cube.
    void setModeEnabled(GameMode m, bool on) { m_modes[idx(m)].enabled = on; }
    void setModeProfile(GameMode m, ProfileId p) { m_modes[idx(m)].profile = p; }
    bool modeEnabled(GameMode m) const { return m_modes[idx(m)].enabled; }
    ProfileId modeProfile(GameMode m) const { return m_modes[idx(m)].profile; }
    bool setCustom(ProfileParams p);                // validates; false = rejected, unchanged
    ProfileParams resolve(GameMode m) const;
    void resetMode(GameMode m) { m_modes[idx(m)] = ModeConfig{}; }
    void resetAll();
    // Clamps out-of-range values; returns false for NaN/inf (use for imported configs).
    static bool validate(ProfileParams& p);
private:
    struct ModeConfig { bool enabled = true; ProfileId profile = ProfileId::Standard; };
    static size_t idx(GameMode m) { return static_cast<size_t>(m) % kModeCount; }
    std::array<ModeConfig, kModeCount> m_modes{};
    ProfileParams m_custom{};
};
}
