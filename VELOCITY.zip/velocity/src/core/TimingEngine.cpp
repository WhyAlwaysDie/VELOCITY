#include "TimingEngine.hpp"
#include <algorithm>
#include <cmath>
namespace vel {
void TimingEngine::reset() { m_head = 0; m_count = 0; m_ema = 0; m_hitches = 0; }
void TimingEngine::onFrame(double dt) {
    if (!(dt > 0.0) || dt > kMaxFrame) { ++m_hitches; return; } // rejects NaN, 0, negatives, pauses
    m_buf[m_head] = dt;
    m_head = (m_head + 1) % kWindow;
    if (m_count < kWindow) ++m_count;
    m_ema = (m_ema == 0.0) ? dt : m_ema + 0.1 * (dt - m_ema);
}
double TimingEngine::mean() const {
    if (!m_count) return 0;
    double s = 0; for (size_t i = 0; i < m_count; ++i) s += m_buf[i];
    return s / static_cast<double>(m_count);
}
double TimingEngine::fps() const { return m_ema > 0 ? 1.0 / m_ema : 0.0; }
double TimingEngine::avgFps() const { double m = mean(); return m > 0 ? 1.0 / m : 0.0; }
double TimingEngine::frameTimeStdDevMs() const {
    double m = mean(); if (m <= 0) return 0;
    double v = 0; for (size_t i = 0; i < m_count; ++i) { double d = m_buf[i] - m; v += d * d; }
    return std::sqrt(v / static_cast<double>(m_count)) * 1000.0;
}
double TimingEngine::consistency() const {
    double m = mean(); if (m <= 0) return 0;
    double cv = (frameTimeStdDevMs() / 1000.0) / m;
    return 1.0 - std::min(1.0, cv);
}
}
