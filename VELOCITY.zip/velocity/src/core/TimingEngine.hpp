#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
namespace vel {
// Frame-time statistics over a fixed window. No allocation; O(window) only when read.
class TimingEngine {
public:
    static constexpr size_t kWindow = 120;
    static constexpr double kMaxFrame = 0.25; // longer frames are pauses/hitches, not data
    void reset();
    void onFrame(double dt);            // dt in seconds
    double fps() const;                 // smoothed (EMA) FPS
    double avgFps() const;              // window average
    double frameTimeStdDevMs() const;
    double consistency() const;         // 1 - min(1, stddev/mean); 1.0 = perfectly even frames
    uint64_t hitches() const { return m_hitches; }
    size_t samples() const { return m_count; }
private:
    double mean() const;
    std::array<double, kWindow> m_buf{};
    size_t m_head = 0, m_count = 0;
    double m_ema = 0;
    uint64_t m_hitches = 0;
};
}
