#pragma once
// Geode-free shared types. Everything under src/core builds and tests without the SDK.
#include <cstddef>
#include <cstdint>

namespace vel {

enum class GameMode : uint8_t { Cube, Ship, Ball, UFO, Wave, Robot, Spider, Swing, Count };
constexpr size_t kModeCount = static_cast<size_t>(GameMode::Count);

enum class ProfileId : uint8_t { Standard, Precision, Adaptive, Experimental, Custom, Count };
enum class InputKind : uint8_t { Press, Release };
enum class Outcome : uint8_t { None, Hit, Miss };

// t is level time in seconds (not wall time), so physics/TPS changes don't skew patterns.
struct InputEvent { double t = 0; InputKind kind = InputKind::Press; };

struct ModeFlags { bool ship = false, ufo = false, ball = false, wave = false,
                        robot = false, spider = false, swing = false; };

struct ProfileParams {
    float confidenceThreshold = 0.60f; // min confidence to issue a prediction
    int   minSamples          = 4;     // min press-to-press intervals before trusting a pattern
    float maxJitter           = 0.15f; // max coefficient of variation of intervals
    float toleranceFrac       = 0.20f; // hit window = toleranceFrac * period (min 10 ms)
    bool  adaptive            = false; // raise threshold while recent hit-rate is low
};

} // namespace vel
