#include "core/AnalyticsManager.hpp"
#include "core/InputAnalyzer.hpp"
#include "core/ModeDetector.hpp"
#include "core/PredictionEngine.hpp"
#include "core/ProfileManager.hpp"
#include "core/TimingEngine.hpp"
#include <cmath>
#include <cstdio>
#include <limits>
using namespace vel;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

static StepResult feed(InputAnalyzer& a, PredictionEngine& e, double t, InputKind k) {
    CHECK(a.record(t, k));
    return e.onInput(t, k, a.estimate());
}

int main() {
    { ModeFlags f; CHECK(detectMode(f) == GameMode::Cube); f.wave = true; CHECK(detectMode(f) == GameMode::Wave);
      f = {}; f.swing = true; CHECK(detectMode(f) == GameMode::Swing); }

    { InputAnalyzer a;
      CHECK(!a.record(0, InputKind::Release));            // release while up
      CHECK(a.record(1.0, InputKind::Press));
      CHECK(!a.record(1.01, InputKind::Press));           // duplicate press
      CHECK(!a.record(0.5, InputKind::Release));          // out of order
      CHECK(!a.record(std::nan(""), InputKind::Release)); // NaN
      CHECK(a.totalEvents() == 1); a.reset(); CHECK(a.totalEvents() == 0 && !a.isDown()); }

    { InputAnalyzer a; PredictionEngine e; e.configure(builtinProfile(ProfileId::Standard), true);
      StepResult r;
      for (int i = 0; i < 4; ++i) { feed(a, e, i * 0.2, InputKind::Press); feed(a, e, i * 0.2 + 0.05, InputKind::Release); }
      r = feed(a, e, 0.8, InputKind::Press);
      auto est = a.estimate();
      CHECK(est.valid && est.samples == 4 && std::fabs(est.period - 0.2) < 1e-9 && std::fabs(est.hold - 0.05) < 1e-9 && est.cv < 1e-9);
      CHECK(r.next.valid && r.next.kind == InputKind::Release && std::fabs(r.next.dueAt - 0.85) < 1e-9);
      r = feed(a, e, 0.852, InputKind::Release);          // within tolerance
      CHECK(r.resolved == Outcome::Hit);
      CHECK(r.next.valid && r.next.kind == InputKind::Press && std::fabs(r.next.dueAt - 1.0) < 1e-9);
      // Expiry: the Press predicted for t=1.0 goes unanswered -> miss, exactly once.
      CHECK(e.pending().valid);
      double due = e.pending().dueAt, tol = e.pending().tolerance;
      CHECK(e.tick(due) == Outcome::None);
      CHECK(e.tick(due + tol + 0.001) == Outcome::Miss);
      CHECK(e.tick(due + 1.0) == Outcome::None);
      e.reset(); CHECK(!e.pending().valid); }

    { // Late real input (150 ms after the predicted Press) is scored as a miss.
      InputAnalyzer a; PredictionEngine e; e.configure(builtinProfile(ProfileId::Standard), true);
      for (int i = 0; i < 4; ++i) { feed(a, e, i * 0.2, InputKind::Press); feed(a, e, i * 0.2 + 0.05, InputKind::Release); }
      feed(a, e, 0.8, InputKind::Press);
      feed(a, e, 0.85, InputKind::Release);               // exact -> hit, next Press due 1.0
      StepResult r = feed(a, e, 1.15, InputKind::Press);
      CHECK(r.resolved == Outcome::Miss); }

    { InputAnalyzer a; PredictionEngine e; e.configure(builtinProfile(ProfileId::Standard), true);
      double t = 0; double gaps[] = {0.1, 0.4, 0.15, 0.5, 0.2, 0.35}; StepResult r;
      for (double g : gaps) { t += g; feed(a, e, t, InputKind::Press); r = feed(a, e, t + 0.03, InputKind::Release); }
      CHECK(!r.next.valid && r.next.reason == Reject::Jittery); }

    { InputAnalyzer a; PredictionEngine e; e.configure(builtinProfile(ProfileId::Standard), false);
      StepResult r; for (int i = 0; i < 6; ++i) { feed(a, e, i * 0.2, InputKind::Press); r = feed(a, e, i * 0.2 + 0.05, InputKind::Release); }
      CHECK(!r.next.valid && r.next.reason == Reject::Disabled); }

    { TimingEngine t; for (int i = 0; i < 200; ++i) t.onFrame(1.0 / 60.0);
      CHECK(std::fabs(t.avgFps() - 60.0) < 0.01 && std::fabs(t.fps() - 60.0) < 0.01 && t.consistency() > 0.999);
      TimingEngine u; for (int i = 0; i < 200; ++i) u.onFrame(i % 2 ? 1.0 / 30 : 1.0 / 120);
      CHECK(u.consistency() < 0.7);
      TimingEngine h; h.onFrame(0); h.onFrame(1.0); h.onFrame(-1); h.onFrame(std::nan(""));
      CHECK(h.hitches() == 4 && h.samples() == 0); }

    { ProfileManager p;
      p.setModeProfile(GameMode::Ship, ProfileId::Precision); p.setModeEnabled(GameMode::Wave, false);
      CHECK(p.modeProfile(GameMode::Cube) == ProfileId::Standard && p.modeEnabled(GameMode::Cube));
      CHECK(p.resolve(GameMode::Ship).minSamples == 6 && !p.modeEnabled(GameMode::Wave));
      ProfileParams bad; bad.maxJitter = std::numeric_limits<float>::quiet_NaN();
      CHECK(!p.setCustom(bad));
      ProfileParams wild; wild.confidenceThreshold = 7; wild.minSamples = 99; wild.maxJitter = 0; wild.toleranceFrac = 9;
      CHECK(p.setCustom(wild)); p.setModeProfile(GameMode::Ball, ProfileId::Custom);
      auto c = p.resolve(GameMode::Ball);
      CHECK(c.confidenceThreshold == 1.0f && c.minSamples == 12 && c.maxJitter == 0.02f && c.toleranceFrac == 0.5f);
      p.resetMode(GameMode::Ship); CHECK(p.modeProfile(GameMode::Ship) == ProfileId::Standard);
      CHECK(parseProfile("precision") == ProfileId::Precision && parseProfile("garbage") == ProfileId::Standard); }

    { AnalyticsManager an; Prediction ok; ok.valid = true; ok.confidence = 0.85f;
      Prediction no; no.reason = Reject::Jittery;
      an.recordInput(GameMode::Ship); an.recordDecision(GameMode::Ship, ok, 2000); an.recordDecision(GameMode::Ship, no, 4000);
      an.recordOutcome(GameMode::Ship, Outcome::Hit); an.recordOutcome(GameMode::Ship, Outcome::None);
      auto s = an.session(GameMode::Ship);
      CHECK(s.attempts == 2 && s.accepted == 1 && s.rejected == 1 && s.hits == 1 && s.misses == 0);
      CHECK(s.confHist[8] == 1 && std::fabs(s.avgProcessingUs() - 3.0) < 1e-9);
      an.resetSession();
      CHECK(an.sessionTotal().attempts == 0 && an.lifetimeTotal().attempts == 2 && an.lifetime(GameMode::Cube).attempts == 0); }

    std::printf(fails ? "%d FAILED\n" : "all core tests passed\n", fails);
    return fails ? 1 : 0;
}
